INSERT INTO nodes VALUES
(1,'Hyderabad',10,18),(2,'Mahbubnagar',24,34),(3,'Kurnool',40,46),(4,'Nandyal',62,36),
(5,'Gooty',52,62),(6,'Anantapur',62,74),(7,'Hindupur',76,84),(8,'Bengaluru',92,92),
(9,'Kadapa',80,50),(10,'Madanapalle',92,68);
INSERT INTO edges (a,b,distance_km,speed_kmph) VALUES
(1,2,100,70),(2,3,90,65),(3,5,80,60),(5,6,40,60),(6,7,100,65),(7,8,60,50),
(3,4,55,55),(4,9,120,60),(9,10,120,55),(10,8,130,55),(6,9,150,55);
INSERT INTO stations (id,node_id,name,power_kw,price_per_kwh,slots_total,slots_free,wait_min) VALUES
(1,1,'Hyderabad Hub',60,20,6,3,4),
(2,2,'Mahbubnagar Plaza',50,18,4,2,5),
(3,3,'Kurnool Fast Charge',120,22,6,0,0),
(4,4,'Nandyal Stop',60,16,4,3,0),
(5,5,'Gooty Highway Point',30,15,2,2,10),
(6,6,'Anantapur Supercharge',120,24,8,4,4),
(7,7,'Hindupur Express',150,26,6,3,3),
(8,9,'Kadapa Station',60,17,4,1,15),
(9,10,'Madanapalle Charge',50,19,3,2,6);
