# EV Charging Planner

Structure: `database/` (SQLite schema + seed), `backend/` (Flask + algorithms), `frontend/` (React + Vite).

## Run
```bash
# Terminal 1 - backend (creates database/ev.db automatically on first run)
cd backend && pip install -r requirements.txt && python app.py

# Terminal 2 - frontend
cd frontend && npm install && npm run dev      # open http://localhost:5173
```

## Algorithms
- Dijkstra (heapq): shortest distance path; also reused by Greedy for distances.
- Greedy + priority queue: from the current location, pops the reachable, available, progress-making station
  with the lowest score (trip km via station + wait penalty), charges just enough (max 80%), repeats.
- State-space Dijkstra: nodes are (location, battery kWh); edges are driving or charging; minimises total time. Optimal benchmark.

## API
GET /api/graph | POST /api/plan | PUT /api/stations/<id>
