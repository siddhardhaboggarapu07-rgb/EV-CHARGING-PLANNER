"""EV charging planner: Dijkstra + Greedy (priority queue) + state-space Dijkstra."""
import heapq, math
from math import inf


class Graph:
    def __init__(self, nodes, edges, stations):
        self.nodes = {n["id"]: n for n in nodes}
        self.adj = {n["id"]: [] for n in nodes}
        self.edge = {}
        for e in edges:
            for u, v in ((e["a"], e["b"]), (e["b"], e["a"])):
                self.adj[u].append(v)
                self.edge[(u, v)] = (e["distance_km"], e["speed_kmph"])
        self.stations = {s["node_id"]: s for s in stations}

    def name(self, n):
        return self.nodes[n]["name"]


def dijkstra(g, src, dst=None, weight="dist"):
    """Least-cost paths with a min-heap. weight: 'dist' (km) or 'time' (min)."""
    dist, prev, done = {src: 0}, {}, set()
    pq = [(0, src)]
    while pq:
        d, u = heapq.heappop(pq)
        if u in done:
            continue
        done.add(u)
        if u == dst:
            break
        for v in g.adj[u]:
            km, sp = g.edge[(u, v)]
            nd = d + (km if weight == "dist" else km / sp * 60)
            if nd < dist.get(v, inf):
                dist[v], prev[v] = nd, u
                heapq.heappush(pq, (nd, v))
    return dist, prev


def path_to(prev, src, dst):
    if dst != src and dst not in prev:
        return None
    p = [dst]
    while p[-1] != src:
        p.append(prev[p[-1]])
    return p[::-1]


def mk_drive(g, u, v, after):
    km, sp = g.edge[(u, v)]
    return dict(type="drive", frm=u, to=v, km=km, min=round(km / sp * 60, 1), kwh_after=round(after, 1))


def mk_charge(g, n, a, b):
    st = g.stations[n]
    return dict(type="charge", node=n, from_kwh=round(a, 1), to_kwh=round(b, 1),
                wait_min=st["wait_min"], charge_min=round((b - a) * 60 / st["power_kw"], 1),
                cost=round((b - a) * st["price_per_kwh"], 1))


def summarize(g, name, actions, log, ok=True):
    drives = [a for a in actions if a["type"] == "drive"]
    charges = [a for a in actions if a["type"] == "charge"]
    path = [drives[0]["frm"]] + [d["to"] for d in drives] if drives else []
    drive_min = sum(d["min"] for d in drives)
    charge_min = sum(c["charge_min"] for c in charges)
    wait_min = sum(c["wait_min"] for c in charges)
    return dict(algorithm=name, feasible=ok, path=path, actions=actions, log=log,
                distance_km=round(sum(d["km"] for d in drives), 1),
                drive_min=round(drive_min, 1), charge_min=round(charge_min, 1),
                wait_min=round(wait_min, 1), total_min=round(drive_min + charge_min + wait_min, 1),
                cost=round(sum(c["cost"] for c in charges), 1), stops=len(charges))


def drive_path(g, nodes, soc, cons, actions):
    for u, v in zip(nodes, nodes[1:]):
        soc -= g.edge[(u, v)][0] * cons
        actions.append(mk_drive(g, u, v, soc))
    return soc


def baseline(g, src, dst, p):
    """Plain Dijkstra on distance, ignoring the battery. Shows if charging is needed."""
    _, prev = dijkstra(g, src, dst)
    path = path_to(prev, src, dst)
    if not path:
        return summarize(g, "Dijkstra (shortest distance)", [], ["Destination is not connected."], False)
    soc0 = p["capacity"] * p["battery_pct"] / 100
    actions = []
    end = drive_path(g, path, soc0, p["cons"], actions)
    ok = end >= p["reserve"]
    log = [f"Shortest path: {' -> '.join(g.name(n) for n in path)}.",
           f"Needs {soc0 - end:.1f} kWh, battery has {soc0:.1f} kWh.",
           "Reachable without charging." if ok else "NOT reachable on the current charge, so charging stops are required."]
    return summarize(g, "Dijkstra (shortest distance)", actions, log, ok)


def greedy(g, src, dst, p):
    """Greedy: repeatedly pop the best reachable, available station from a priority queue."""
    name = "Greedy (priority queue)"
    cap, cons, res = p["capacity"], p["cons"], p["reserve"]
    soc = cap * p["battery_pct"] / 100
    cur, actions, log, charged = src, [], [], set()
    d_dst, _ = dijkstra(g, dst)
    if src not in d_dst:
        return summarize(g, name, [], ["Destination is not connected."], False)

    def charge_at(n, soc):
        need_dest = d_dst[n] * cons + res
        target = min(cap * 0.8, need_dest)
        charged.add(n)
        if target <= soc + 0.01:
            return soc
        actions.append(mk_charge(g, n, soc, target))
        log.append(f"Charge at {g.name(n)}: {soc:.1f} -> {target:.1f} kWh "
                   f"({'just enough for destination' if target == need_dest else 'up to 80% cap'}).")
        return target

    while True:
        d_cur, prev = dijkstra(g, cur)
        if d_cur[dst] * cons + res <= soc:
            soc = drive_path(g, path_to(prev, cur, dst), soc, cons, actions)
            log.append(f"From {g.name(cur)} the destination is reachable ({d_cur[dst]:.0f} km). Done.")
            return summarize(g, name, actions, log)
        pq = []
        for n, st in g.stations.items():
            if n == cur or n not in d_cur or st["slots_free"] <= 0:
                continue
            if d_cur[n] * cons + res > soc or d_dst[n] >= d_dst[cur]:
                continue  # unreachable, or no progress toward destination
            key = d_cur[n] + d_dst[n] + st["wait_min"] * 0.5  # remaining trip km + wait penalty
            heapq.heappush(pq, (key, n))
        if not pq:
            if cur in g.stations and cur not in charged and g.stations[cur]["slots_free"] > 0:
                soc = charge_at(cur, soc)
                continue
            log.append(f"Stuck at {g.name(cur)}: no reachable available station makes progress.")
            return summarize(g, name, actions, log, False)
        key, n = heapq.heappop(pq)
        log.append(f"At {g.name(cur)} with {soc:.1f} kWh: picked {g.name(n)} "
                   f"(score {key:.0f} = trip km via station + wait penalty) from {len(pq) + 1} candidate(s).")
        soc = drive_path(g, path_to(prev, cur, n), soc, cons, actions)
        soc = charge_at(n, soc)
        cur = n


def optimal(g, src, dst, p):
    """Dijkstra over states (node, battery kWh): minimises total time (drive+wait+charge)."""
    name = "Dijkstra (state-space optimal)"
    cap, cons = int(p["capacity"]), p["cons"]
    res = math.ceil(p["reserve"])
    s0 = int(p["capacity"] * p["battery_pct"] / 100)
    start = (src, s0)
    best, prev, pq = {start: 0}, {}, [(0, start)]
    while pq:
        t, (u, s) = heapq.heappop(pq)
        if t > best.get((u, s), inf):
            continue
        if u == dst:
            actions, st = [], (u, s)
            while st in prev:
                pst, act = prev[st]
                actions.append(act)
                st = pst
            actions.reverse()
            return summarize(g, name, actions,
                             [f"Explored {len(best)} (location, battery) states; minimum time = {t:.1f} min.",
                              "Guaranteed fastest plan under the same availability and reserve rules."])
        moves = []
        for v in g.adj[u]:
            km, sp = g.edge[(u, v)]
            ns = s - math.ceil(km * cons)
            if ns >= res:
                moves.append((t + km / sp * 60, (v, ns), mk_drive(g, u, v, ns)))
        st = g.stations.get(u)
        if st and st["slots_free"] > 0:
            for tgt in range(s + 1, cap + 1):
                c = t + st["wait_min"] + (tgt - s) * 60 / st["power_kw"]
                moves.append((c, (u, tgt), mk_charge(g, u, s, tgt)))
        for c, ns, act in moves:
            if c < best.get(ns, inf):
                best[ns], prev[ns] = c, ((u, s), act)
                heapq.heappush(pq, (c, ns))
    return summarize(g, name, [], ["No feasible plan with current battery and station availability."], False)


def plan(g, src, dst, p):
    p["reserve"] = p["capacity"] * 0.05
    return {"baseline": baseline(g, src, dst, p), "greedy": greedy(g, src, dst, p),
            "optimal": optimal(g, src, dst, p)}
