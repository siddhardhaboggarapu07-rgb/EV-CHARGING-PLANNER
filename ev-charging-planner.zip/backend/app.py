import os, sqlite3
from flask import Flask, jsonify, request
from flask_cors import CORS
from planner import Graph, plan

BASE = os.path.dirname(os.path.abspath(__file__))
DB_DIR = os.path.join(BASE, "..", "database")
DB = os.path.join(DB_DIR, "ev.db")

app = Flask(__name__)
CORS(app)


def init_db():
    if os.path.exists(DB):
        return
    conn = sqlite3.connect(DB)
    for f in ("schema.sql", "seed.sql"):
        conn.executescript(open(os.path.join(DB_DIR, f)).read())
    conn.commit()
    conn.close()


def query(sql, args=(), write=False):
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    cur = conn.execute(sql, args)
    rows = [dict(r) for r in cur.fetchall()]
    if write:
        conn.commit()
    conn.close()
    return rows


def load():
    return query("SELECT * FROM nodes"), query("SELECT * FROM edges"), query("SELECT * FROM stations")


@app.get("/api/graph")
def graph():
    n, e, s = load()
    return jsonify(nodes=n, edges=e, stations=s)


@app.post("/api/plan")
def plan_route():
    d = request.get_json(force=True)
    try:
        src, dst = int(d["source"]), int(d["destination"])
        p = dict(battery_pct=float(d.get("battery_pct", 60)),
                 capacity=float(d.get("capacity", 40)), cons=float(d.get("cons", 0.16)))
    except (KeyError, ValueError):
        return jsonify(error="Provide source, destination, battery_pct, capacity and cons."), 400
    if src == dst:
        return jsonify(error="Source and destination must differ."), 400
    if not (0 < p["battery_pct"] <= 100 and p["capacity"] > 0 and p["cons"] > 0):
        return jsonify(error="Battery %, capacity and consumption must be positive."), 400
    g = Graph(*load())
    if src not in g.nodes or dst not in g.nodes:
        return jsonify(error="Unknown location."), 400
    return jsonify(plan(g, src, dst, p))


@app.put("/api/stations/<int:sid>")
def update_station(sid):
    d = request.get_json(force=True)
    row = query("SELECT * FROM stations WHERE id=?", (sid,))
    if not row:
        return jsonify(error="Station not found."), 404
    free = max(0, min(int(d.get("slots_free", row[0]["slots_free"])), row[0]["slots_total"]))
    query("UPDATE stations SET slots_free=? WHERE id=?", (free, sid), write=True)
    return jsonify(id=sid, slots_free=free)


if __name__ == "__main__":
    init_db()
    app.run(port=5000, debug=True)
