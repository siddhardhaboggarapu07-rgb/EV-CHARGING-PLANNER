import { useEffect, useState } from "react";

const TABS = [
  ["baseline", "Shortest path", "#8a8f98"],
  ["greedy", "Greedy", "#e0852b"],
  ["optimal", "Optimal", "#1f9d6b"],
];

export default function App() {
  const [graph, setGraph] = useState(null);
  const [form, setForm] = useState({ source: 1, destination: 8, battery_pct: 60, capacity: 40, cons: 0.16 });
  const [result, setResult] = useState(null);
  const [tab, setTab] = useState("greedy");
  const [error, setError] = useState("");

  const loadGraph = () => fetch("/api/graph").then(r => r.json()).then(setGraph)
    .catch(() => setError("Backend not reachable. Start it with: python app.py"));
  useEffect(() => { loadGraph(); }, []);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  async function run() {
    setError("");
    const r = await fetch("/api/plan", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form),
    });
    const data = await r.json();
    if (!r.ok) return setError(data.error);
    setResult(data);
  }

  async function toggle(st) {
    await fetch(`/api/stations/${st.id}`, {
      method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slots_free: st.slots_free > 0 ? 0 : st.slots_total }),
    });
    await loadGraph();
    if (result) run();
  }

  if (!graph) return <p className="boot">{error || "Loading map…"}</p>;
  const name = id => graph.nodes.find(n => n.id === id)?.name;
  const stationAt = id => graph.stations.find(s => s.node_id === id);
  const node = id => graph.nodes.find(n => n.id === id);
  const active = result?.[tab];
  const color = TABS.find(t => t[0] === tab)[2];
  const onPath = (a, b) => active?.path.some((n, i) => (n === a && active.path[i + 1] === b) || (n === b && active.path[i + 1] === a));

  return (
    <div className="app">
      <header><h1>EV Charging Planner</h1><p>Plan where to stop, how long to charge, and compare how three algorithms decide.</p></header>

      <section className="panel controls">
        <label>From<select value={form.source} onChange={e => set("source", +e.target.value)}>
          {graph.nodes.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}</select></label>
        <label>To<select value={form.destination} onChange={e => set("destination", +e.target.value)}>
          {graph.nodes.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}</select></label>
        <label>Battery now (%)<input type="number" min="1" max="100" value={form.battery_pct} onChange={e => set("battery_pct", +e.target.value)} /></label>
        <label>Capacity (kWh)<input type="number" min="1" value={form.capacity} onChange={e => set("capacity", +e.target.value)} /></label>
        <label>Use (kWh/km)<input type="number" step="0.01" min="0.01" value={form.cons} onChange={e => set("cons", +e.target.value)} /></label>
        <button onClick={run}>Plan trip</button>
      </section>
      {error && <p className="error" role="alert">{error}</p>}

      <div className="grid">
        <section className="panel">
          <svg viewBox="0 0 100 100" className="map" role="img" aria-label="Road network with charging stations">
            {graph.edges.map(e => {
              const a = node(e.a), b = node(e.b), hit = onPath(e.a, e.b);
              return <g key={e.id}>
                <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={hit ? color : "#c9cfd6"} strokeWidth={hit ? 1.6 : 0.5} />
                <text x={(a.x + b.x) / 2} y={(a.y + b.y) / 2 - 1} className="km">{e.distance_km}</text>
              </g>;
            })}
            {graph.nodes.map(n => {
              const st = stationAt(n.id), visited = active?.path.includes(n.id);
              const stop = active?.actions.some(a => a.type === "charge" && a.node === n.id);
              return <g key={n.id}>
                <circle cx={n.x} cy={n.y} r={stop ? 3.2 : 2.2} fill={st ? (st.slots_free > 0 ? "#1f9d6b" : "#d64545") : "#5b6573"}
                  stroke={visited ? color : "#fff"} strokeWidth="0.9" />
                <text x={n.x} y={n.y + 6} textAnchor="middle" className="label">{n.name}</text>
              </g>;
            })}
          </svg>
          <p className="legend"><span className="dot g" />station free <span className="dot r" />station full <span className="dot n" />no station. Larger dot = charging stop. Numbers are km.</p>
        </section>

        <section className="panel">
          <h2>Stations</h2>
          <ul className="stations">
            {graph.stations.map(s => <li key={s.id}>
              <div><strong>{name(s.node_id)}</strong><br /><small>{s.power_kw} kW, ₹{s.price_per_kwh}/kWh, wait {s.wait_min} min</small></div>
              <button className={s.slots_free ? "ghost" : "ghost off"} onClick={() => toggle(s)}>
                {s.slots_free}/{s.slots_total} free{s.slots_free ? ": mark full" : ": mark free"}</button>
            </li>)}
          </ul>
        </section>
      </div>

      {result && <>
        <section className="panel">
          <h2>Comparison</h2>
          <div className="scroll"><table>
            <thead><tr><th>Algorithm</th><th>Feasible</th><th>Distance</th><th>Stops</th><th>Drive</th><th>Wait</th><th>Charge</th><th>Total time</th><th>Cost</th></tr></thead>
            <tbody>{TABS.map(([k]) => { const r = result[k]; return (
              <tr key={k} className={tab === k ? "sel" : ""} onClick={() => setTab(k)}>
                <td>{r.algorithm}</td><td>{r.feasible ? "Yes" : "No"}</td><td>{r.distance_km} km</td><td>{r.stops}</td>
                <td>{r.drive_min} min</td><td>{r.wait_min} min</td><td>{r.charge_min} min</td>
                <td><strong>{r.total_min} min</strong></td><td>₹{r.cost}</td></tr>); })}</tbody>
          </table></div>
          <div className="tabs">{TABS.map(([k, l]) => <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}>{l}</button>)}</div>
        </section>

        <div className="grid">
          <section className="panel">
            <h2>Itinerary: {active.algorithm}</h2>
            {!active.feasible && <p className="error">This plan cannot complete the trip.</p>}
            <ol className="steps">
              {active.actions.map((a, i) => a.type === "drive"
                ? <li key={i}>Drive {name(a.frm)} to {name(a.to)}: {a.km} km, {a.min} min, battery {a.kwh_after} kWh on arrival</li>
                : <li key={i} className="charge">Charge at {name(a.node)}: {a.from_kwh} to {a.to_kwh} kWh, wait {a.wait_min} min + {a.charge_min} min, ₹{a.cost}</li>)}
            </ol>
          </section>
          <section className="panel">
            <h2>Why this result</h2>
            <ul className="log">{active.log.map((l, i) => <li key={i}>{l}</li>)}</ul>
          </section>
        </div>
      </>}
    </div>
  );
}
